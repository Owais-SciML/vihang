import pigpio
from time import sleep

# Servo setup
servo_pin = 17
pi = pigpio.pi()

if not pi.connected:
    print("Error: pigpio daemon not running. Start it using: sudo pigpiod")
    exit()

# Pulse width limits (microseconds)
MIN_PW = 600
MAX_PW = 2300

def set_angle(angle):
    """Map angle (-90 to 90) to servo pulse width."""
    pw = int(MIN_PW + (angle + 90) * (MAX_PW - MIN_PW) / 180)
    pi.set_servo_pulsewidth(servo_pin, pw)

try:
    while True:
        # Take user input every loop
        try:
            angle = float(input("Enter angle (-90 to 90, Ctrl+C to exit): "))
        except ValueError:
            print("Invalid value. Please enter a number.")
            continue
        if not -90 <= angle <= 90:
            print("Angle out of range. Must be between -90 and 90.")
            continue
        set_angle(angle)
        sleep(0.5)  # Give time for servo to move
except KeyboardInterrupt:
    print("\nStopped by user.")
finally:
    pi.set_servo_pulsewidth(servo_pin, 0)  # stop PWM
    pi.stop()
