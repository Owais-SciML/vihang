#!/usr/bin/env python3
# esc_diag.py  -- minimal diagnostic pulse test (ASCII only)
import pigpio, time

ESC_PIN = 18      # BCM pin 18 (physical 12)
MIN_US = 1000
MID_US = 1500
MAX_US = 2000

pi = pigpio.pi()
if not pi.connected:
    print("pigpio not running. Start it: sudo pigpiod")
    raise SystemExit(1)

try:
    print("Ensure props removed. Waiting 2s...")
    time.sleep(2)

    print("Sending MIN ({} us)".format(MIN_US))
    pi.set_servo_pulsewidth(ESC_PIN, MIN_US)
    time.sleep(2)
    print("Readback:", pi.get_servo_pulsewidth(ESC_PIN))

    print("Sending MID ({} us)".format(MID_US))
    pi.set_servo_pulsewidth(ESC_PIN, MID_US)
    time.sleep(2)
    print("Readback:", pi.get_servo_pulsewidth(ESC_PIN))

    print("Sending MAX ({} us)".format(MAX_US))
    pi.set_servo_pulsewidth(ESC_PIN, MAX_US)
    time.sleep(3)
    print("Readback:", pi.get_servo_pulsewidth(ESC_PIN))

    print("Returning to MIN")
    pi.set_servo_pulsewidth(ESC_PIN, MIN_US)
    time.sleep(1)
    print("Stopping pulses (0)")
    pi.set_servo_pulsewidth(ESC_PIN, 0)

finally:
    pi.stop()
    print("Done")
