# app.py
from flask import Flask, request, redirect, url_for, render_template_string, session, flash
import smtplib
import numpy as np
import time

app = Flask(__name__)
app.secret_key = "change_this_to_a_random_secret"  # change for production

# --- Global variable as requested ---
receiver_email = None  # will be set when user submits login form

# --- SMTP sender credentials (as you gave them) ---
email = "hackkali1295@gmail.com"
smtp_password = "sdbq syla dpib nhqa"  # use careful handling in real apps

# --- Templates (no utf-8 meta tag) ---
INDEX_HTML = """
<!doctype html>
<html>
<head>
  <title>Login</title>
</head>
<body>
  <h2>Enter Email & Name</h2>
  {% with messages = get_flashed_messages() %}
    {% if messages %}
      <ul style="color:red;">
      {% for m in messages %}<li>{{m}}</li>{% endfor %}
      </ul>
    {% endif %}
  {% endwith %}
  <form method="post" action="{{ url_for('send_otp') }}">
    Email:<br>
    <input type="email" name="email" required><br><br>
    Name:<br>
    <input type="text" name="name" required><br><br>
    <button type="submit">Authenticate</button>
  </form>
</body>
</html>
"""

VERIFY_HTML = """
<!doctype html>
<html>
<head>
  <title>Enter OTP</title>
</head>
<body>
  <h2>Verify OTP</h2>
  <p>OTP sent to: <strong>{{ email_display }}</strong></p>

  {% with messages = get_flashed_messages() %}
    {% if messages %}
      <ul style="color:red;">
      {% for m in messages %}<li>{{m}}</li>{% endfor %}
      </ul>
    {% endif %}
  {% endwith %}

  <form method="post" action="{{ url_for('verify_otp') }}">
    <input type="hidden" name="email" value="{{ email_display }}">
    Enter OTP: <input type="text" name="otp" pattern="\\d{6}" required><br><br>
    <button type="submit">Continue</button>
  </form>

  <form method="get" action="{{ url_for('change_email') }}" style="margin-top:1rem;">
    <button type="submit">Change email</button>
  </form>
</body>
</html>
"""

MAIN_HTML = """
<!doctype html>
<html>
<head>
  <title>Main Page</title>
</head>
<body>
  <h2>Main Page</h2>
  <p>Welcome, {{ name }} ({{ email }})</p>
  <p><a href="{{ url_for('logout') }}">Logout</a></p>
</body>
</html>
"""

# --- Routes ---
@app.route("/", methods=["GET"])
def index():
    # show login page
    return render_template_string(INDEX_HTML)

@app.route("/send_otp", methods=["POST"])
def send_otp():
    global receiver_email
    name = request.form.get("name", "").strip()
    recv = request.form.get("email", "").strip().lower()

    if not name or not recv:
        flash("Name and email required")
        return redirect(url_for("index"))

    # store receiver_email variable (module-level) as requested
    receiver_email = recv

    # store in session for later verification and show on verify page
    session["pending_name"] = name
    session["pending_email"] = recv

    # generate otp using numpy as you requested
    otp = np.random.randint(100000, 1000000)  # 6-digit
    session["pending_otp"] = str(int(otp))  # store as string
    session["otp_time"] = int(time.time())   # timestamp if you want expiry

    # Prepare message exactly like you specified
    subject = "ALert !!! "
    message = "your otp is : ", otp
    message = ''.join(map(str, message))

    text = f"Subject: {subject}\n\n{message}"

    # send email using smtplib (your code)
    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(email, smtp_password)
        server.sendmail(email, receiver_email, text)
        server.quit()
        print("Email has been sent to " + receiver_email)
    except Exception as e:
        # On failure, show a message and allow user to retry
        flash(f"Failed to send OTP email: {e}")
        return redirect(url_for("index"))

    return redirect(url_for("verify"))

@app.route("/verify", methods=["GET"])
def verify():
    email_display = session.get("pending_email")
    if not email_display:
        return redirect(url_for("index"))
    return render_template_string(VERIFY_HTML, email_display=email_display)

@app.route("/verify_otp", methods=["POST"])
def verify_otp():
    entered = request.form.get("otp", "").strip()
    stored = session.get("pending_otp")
    if not stored:
        flash("No OTP pending. Please authenticate again.")
        return redirect(url_for("index"))

    if entered == stored:
        # OTP correct => mark logged in and go to main
        session["logged_in"] = True
        session["name"] = session.get("pending_name")
        session["email"] = session.get("pending_email")
        # clear pending otp
        session.pop("pending_otp", None)
        return redirect(url_for("main"))
    else:
        flash("Incorrect OTP. Please try again.")
        return redirect(url_for("verify"))

@app.route("/change_email", methods=["GET"])
def change_email():
    # clear pending and go back to index to edit
    session.pop("pending_email", None)
    session.pop("pending_name", None)
    session.pop("pending_otp", None)
    return redirect(url_for("index"))

@app.route("/main", methods=["GET"])
def main():
    if not session.get("logged_in"):
        return redirect(url_for("index"))
    return render_template_string(MAIN_HTML, name=session.get("name"), email=session.get("email"))

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

if __name__ == "__main__":
    # Run on localhost
    app.run(debug=True)
