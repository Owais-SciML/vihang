#!/usr/bin/env python3
# Simple Flask + pigpio web UI to run one ESC by percent or RPM for a given time.
# ASCII-only HTML (no charset meta). Start pigpiod before running.
# Run: sudo pigpiod


import time
import threading
from flask import Flask, request, jsonify
import pigpio # type: ignore

# ====== CONFIG ======
ESC_PIN = 18       # BCM pin for ESC signal (physical 12)
MIN_US = 1000      # microseconds (min throttle)
MAX_US = 2000      # microseconds (max throttle)
KV = 1000.0        # motor KV (used only if using 'rpm' mode)
VBATT = 12.8       # battery voltage (used only if using 'rpm' mode)
# ====== END CONFIG ======

app = Flask(__name__)

pi = pigpio.pi()
if not pi.connected:
    print("pigpio not running. start it: sudo pigpiod")
    raise SystemExit(1)

# state
state_lock = threading.Lock()
current_pulse = MIN_US
running = False
run_thread = None
run_cancel = threading.Event()

def percent_to_pulse(pct):
    p = max(0.0, min(100.0, float(pct)))
    return int(MIN_US + (p / 100.0) * (MAX_US - MIN_US))

def rpm_to_pulse(rpm):
    try:
        r = float(rpm)
    except:
        r = 0.0
    max_rpm = KV * VBATT
    if max_rpm <= 0.0:
        return MIN_US
    pct = (r / max_rpm) * 100.0
    return percent_to_pulse(pct)

def set_pulse(us):
    global current_pulse
    pi.set_servo_pulsewidth(ESC_PIN, int(us))
    current_pulse = int(us)

def stop_motor():
    global running
    set_pulse(MIN_US)
    running = False

def start_motor_for(pulse, duration):
    global running, run_thread, run_cancel
    # cancel previous
    run_cancel.set()
    if run_thread and run_thread.is_alive():
        run_thread.join()
    run_cancel.clear()

    def _run():
        global running
        with state_lock:
            running = True
            set_pulse(pulse)
        if duration > 0:
            start = time.time()
            while time.time() - start < duration:
                if run_cancel.is_set():
                    break
                time.sleep(0.05)
            stop_motor()
        # if duration == 0, run until cancelled by /stop
    run_thread = threading.Thread(target=_run, daemon=True)
    run_thread.start()
    return run_thread

# ========== Routes ==========
INDEX_HTML = """
<!doctype html>
<html>
<head><title>ESC Web Control</title></head>
<body>
<h2>ESC Web Control</h2>
<p>Safety: remove props. Make sure ESC ground and Pi ground share common ground.</p>

Mode:
<select id="mode">
  <option value="pct">pct (0-100)</option>
  <option value="rpm">rpm</option>
</select>
<br><br>
Value: <input id="value" type="number" value="50"> (pct or rpm depending on mode)
<br><br>
Duration (s, 0 for indefinite): <input id="dur" type="number" step="0.1" value="0">
<br><br>
<button onclick="start()">START</button>
<button onclick="stop()">STOP</button>

<p id="msg"></p>
<p>Status: pulse <span id="pulse"></span> us, running <span id="run"></span></p>

<script>
function el(id){ return document.getElementById(id); }
async function start(){
  const data = {
    mode: el('mode').value,
    value: el('value').value,
    duration: el('dur').value
  };
  el('msg').innerText = 'Sending...';
  try {
    const r = await fetch('/start', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(data)
    });
    const j = await r.json();
    el('msg').innerText = j.msg || JSON.stringify(j);
  } catch(e){
    el('msg').innerText = 'Error: ' + e;
  }
}
async function stop(){
  await fetch('/stop', {method:'POST'});
  el('msg').innerText = 'Stop sent';
}
async function poll(){
  try {
    const r = await fetch('/status');
    const j = await r.json();
    el('pulse').innerText = j.current_pulse;
    el('run').innerText = j.running;
  } catch(e){}
  setTimeout(poll, 500);
}
poll();
</script>
</body>
</html>
"""

@app.route("/")
def index():
    return INDEX_HTML

@app.route("/start", methods=["POST"])
def start():
    data = request.get_json() or {}
    mode = data.get("mode", "pct")
    val = data.get("value", "0")
    dur = data.get("duration", "0")
    try:
        durf = float(dur)
    except:
        durf = 0.0

    if mode == "pct":
        try:
            pulse = percent_to_pulse(val)
        except:
            return jsonify({"msg":"invalid percent"}), 400
    else:
        try:
            pulse = rpm_to_pulse(val)
        except:
            return jsonify({"msg":"invalid rpm"}), 400

    # send MIN first for safety
    set_pulse(MIN_US)
    time.sleep(0.2)
    start_motor_for(pulse, durf)
    return jsonify({"msg":"started", "pulse": pulse})

@app.route("/stop", methods=["POST"])
def stop_route():
    run_cancel.set()
    stop_motor()
    return jsonify({"msg":"stopped"})

@app.route("/status")
def status():
    return jsonify({"current_pulse": current_pulse, "running": running})

# cleanup on exit
def cleanup():
    try:
        stop_motor()
        pi.set_servo_pulsewidth(ESC_PIN, 0)
        pi.stop()
    except:
        pass

if __name__ == "__main__":
    try:
        print("Start pigpiod first: sudo pigpiod")
        app.run(host="0.0.0.0", port=5000, threaded=True)
    finally:
        cleanup()
