#!/usr/bin/env python3
# run_simple_percent.py
# Run ESC by percent throttle or RPM for a given time.
# Uses pigpio. ASCII only.

import time, pigpio, cv2, mediapipe as mp, math

ESC_PIN = 18
MIN_US = 1000
MAX_US = 2000
KV = 1000.0
VBATT = 12.8
MIN_RPM = 1000
MAX_RPM = 3000

def percent_to_pulse(p):
    p = max(0.0, min(100.0, float(p)))
    return int(MIN_US + (p/100.0) * (MAX_US - MIN_US))

def rpm_to_pulse(rpm):
    try:
        r = float(rpm)
    except:
        r = 0.0
    max_rpm = KV * VBATT
    if max_rpm <= 0:
        return MIN_US
    pct = (r / max_rpm) * 100.0
    return percent_to_pulse(pct)

# Setup pigpio
pi = pigpio.pi()
if not pi.connected:
    print("pigpio not running. Start it: sudo pigpiod")
    exit()

# Initialize ESC
pi.set_servo_pulsewidth(ESC_PIN, MIN_US)
print("ESC initialized, keep props OFF.")
time.sleep(2)

# Setup MediaPipe Hands
mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils
hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Cannot access camera.")
    exit()

print("Showing live feed... Move your hand to control RPM (Thumb–Index distance). Press 'q' to quit.")

try:
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = hands.process(rgb)

        rpm = MIN_RPM  # Default RPM

        if result.multi_hand_landmarks:
            for handLms in result.multi_hand_landmarks:
                mp_draw.draw_landmarks(frame, handLms, mp_hands.HAND_CONNECTIONS)

                # Get coordinates of thumb tip (4) and index tip (8)
                h, w, _ = frame.shape
                x1, y1 = int(handLms.landmark[4].x * w), int(handLms.landmark[4].y * h)
                x2, y2 = int(handLms.landmark[8].x * w), int(handLms.landmark[8].y * h)

                cv2.circle(frame, (x1, y1), 8, (0, 255, 0), -1)
                cv2.circle(frame, (x2, y2), 8, (0, 255, 0), -1)
                cv2.line(frame, (x1, y1), (x2, y2), (255, 0, 0), 2)

                # Compute Euclidean distance
                dist = math.hypot(x2 - x1, y2 - y1)

                # Map distance (say 30–250 px) to RPM range (1000–3000)
                dist = max(30, min(250, dist))
                rpm = MIN_RPM + (dist - 30) * (MAX_RPM - MIN_RPM) / (250 - 30)

                cv2.putText(frame, f'RPM: {int(rpm)}', (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

        # Convert RPM to pulse and send to ESC
        pulse = rpm_to_pulse(rpm)
        pi.set_servo_pulsewidth(ESC_PIN, pulse)

        cv2.imshow("Hand RPM Control", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except KeyboardInterrupt:
    pass

finally:
    print("\nStopping motor and cleaning up...")
    pi.set_servo_pulsewidth(ESC_PIN, MIN_US)
    time.sleep(1)
    pi.set_servo_pulsewidth(ESC_PIN, 0)
    pi.stop()
    cap.release()
    cv2.destroyAllWindows()
    print("Cleaned up and exited safely.")
