#!/usr/bin/env python3
# run_simple_percent.py
# Run ESC by percent throttle or RPM for a given time.
# Uses pigpio. ASCII only.

import time, pigpio

ESC_PIN = 18
MIN_US = 1000
MAX_US = 2000
KV = 1000.0
VBATT = 12.8

def percent_to_pulse(p):
    p = max(0.0, min(100.0, float(p)))
    return int(MIN_US + (p/100.0) * (MAX_US - MIN_US))

def rpm_to_pulse(rpm):
    try:
        r = float(rpm)
    except:
        r = 0.0
    max_rpm = KV * VBATT
    if max_rpm <= 0:
        return MIN_US
    pct = (r / max_rpm) * 100.0
    return percent_to_pulse(pct)

def main():
    pi = pigpio.pi()
    if not pi.connected:
        print("pigpio not running. Start it: sudo pigpiod")
        return

    try:
        mode = input("Enter 'pct' for throttle percent or 'rpm' for RPM mapping: ").strip().lower()
        if mode == 'pct':
            val = input("Enter throttle percent (0-100): ").strip()
            pulse = percent_to_pulse(val)
        else:
            val = input("Enter target RPM: ").strip()
            pulse = rpm_to_pulse(val)

        dur = input("Enter duration in seconds (0 for indefinite): ").strip()
        try:
            dur = float(dur)
        except:
            dur = 0.0

        input("Remove props and press Enter to start...")

        # ensure MIN first
        pi.set_servo_pulsewidth(ESC_PIN, MIN_US)
        time.sleep(1.0)

        print("Setting pulse:", pulse, "us")
        pi.set_servo_pulsewidth(ESC_PIN, pulse)

        if dur > 0:
            time.sleep(dur)
            print("Time up, setting MIN and stopping")
            pi.set_servo_pulsewidth(ESC_PIN, MIN_US)
        else:
            print("Running indefinitely. Press Ctrl+C to stop.")
            try:
                while True:
                    time.sleep(0.5)
            except KeyboardInterrupt:
                print("Stopping (MIN)")
                pi.set_servo_pulsewidth(ESC_PIN, MIN_US)

    finally:
        pi.set_servo_pulsewidth(ESC_PIN, 0)
        pi.stop()
        print("Cleaned up.")

if __name__ == '__main__':
    main()
